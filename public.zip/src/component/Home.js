import React from 'react'

const Home=()=> {
  return (
    <>
    <div className='container'>
     <div className="row ">
      <div className="col-md-6 p-5">
      <h1 className='fw-light fs-6' >Our Story</h1>
      <hr className='w-25 text-warning p-1'/>
      <h2 className='fs-1 mt-3 mb-4'>Welcome to Royal</h2>
      <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium ,totam rem aperiam,eaque ipsa ab illo inventore
    veritatis et quasi architechtoeague ipsa ab illo inventore.</p>
    <br/>
    <br/>
    <p>
    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium ,totam rem aperiam,eaque ipsa ab illo inventore
    veritatis et quasi architechtoeague ipsa ab illo inventore.
    </p>
      
     </div>
     
      <div className="col-md-6 p-5">
      <img src="./images/story.jpg" alt="ouyr story"  className='img-fluid h-75 m-auto p-5 pt-0'/>
     
      </div>
     </div>

    </div>
      
    </>
  )
}
export default Home;
